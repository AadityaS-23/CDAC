package com.blogs.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController //cls level annotation - @Controller : added at the class level 
//+ @ResponseBody - added implicitly on ret types of all request handling methods
@RequestMapping("/test")
public class TestController {
	public TestController() {
		System.out.println("in ctor "+getClass());
	}
	//add HTTP - request handling method for getting list of numbers
	@GetMapping("/numbers")
	public List<Integer> getNumberList() {
		System.out.println("in get num list");
		return List.of(1,2,3,4,5,6);
	}

}
