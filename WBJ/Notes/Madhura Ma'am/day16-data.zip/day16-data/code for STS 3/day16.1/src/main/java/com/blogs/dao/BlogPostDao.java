package com.blogs.dao;

import java.util.List;

import com.blogs.pojos.BlogPost;

public interface BlogPostDao {
//add a method to get all blogs
	List<BlogPost> getAllBlogs();

	String deletePost(Long blogId);
}
