package com.blogs.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.blogs.pojos.BlogPost;

@Repository
public class BlogPostDaoImpl implements BlogPostDao {
	//depcy
	@Autowired
	private EntityManager entityManager;
	

	@Override
	public List<BlogPost> getAllBlogs() {
		String jpql="select bp from BlogPost bp where bp.available=true";
		return entityManager.createQuery(jpql, BlogPost.class)
				.getResultList();
				
	}


	@Override
	public String deletePost(Long blogId) {
		BlogPost blogPost = entityManager.find(BlogPost.class, blogId);
		if(blogPost != null) {
			//blogPost - persistent
			blogPost.setAvailable(false);//modifying state of the persistent entity
			return "Blog post unavailable !";
		}
		return "Deleting blog post failed!!!!";
	}
	

}
