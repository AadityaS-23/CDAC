package com.blogs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.blogs.dao.BlogPostDao;
import com.blogs.pojos.BlogPost;

@Service
@Transactional
public class BlogPostServiceImpl implements BlogPostService {
	//depcy
	@Autowired
	private BlogPostDao blogPostDao;

	@Override
	public List<BlogPost> getAllPosts() {
		// TODO Auto-generated method stub
		return blogPostDao.getAllBlogs();
	}

	@Override
	public String deleteBlogPost(Long blogId) {
		// TODO Auto-generated method stub
		return blogPostDao.deletePost(blogId);
	}
	/*service layer (@Tx) rets -- Tx mgr(spring supplied) 
	 * auto commits the tx in case of no errs
	 * OR
	 * rolls back Tx in case of any run time exception
	*/
	

}
