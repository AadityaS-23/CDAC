package com.blogs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.blogs.service.BlogPostService;

@Controller
@RequestMapping("/bloggers")
public class BloggerController {
	//depcy 
	@Autowired
	private BlogPostService blogPostService;
	
	public BloggerController() {
		System.out.println("in ctor of"+getClass());
	}
	//add request handling method to render blogger's home page
	//http://localhost:8080/ctx/bloggers/home , method=GET
	@GetMapping("/home")
	public String showBloggerHomePage(Model modelMap) {
		System.out.println("in show blogger hm page "+modelMap);
		modelMap.addAttribute("all_blogs",blogPostService.getAllPosts());
		return "/bloggers/home";//LVN --> D.S --> V.R --> AVN : /WEB-INF/views/blogger/home.jsp
	}
	

}
