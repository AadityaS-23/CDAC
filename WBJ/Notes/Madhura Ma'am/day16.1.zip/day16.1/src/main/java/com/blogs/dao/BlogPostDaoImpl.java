package com.blogs.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.blogs.pojos.BlogPost;

@Repository
public class BlogPostDaoImpl implements BlogPostDao {
	//depcy
	@Autowired
	private EntityManager entityManager;
	

	@Override
	public List<BlogPost> getAllBlogs() {
		String jpql="select bp from BlogPost bp";
		return entityManager.createQuery(jpql, BlogPost.class)
				.getResultList();
				
	}

}
