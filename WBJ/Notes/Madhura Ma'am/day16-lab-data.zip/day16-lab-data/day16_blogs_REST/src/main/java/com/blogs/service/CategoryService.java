package com.blogs.service;

import java.util.List;

import com.blogs.pojos.Category;

public interface CategoryService {
//add a method to get all categories
	List<Category> getAllCategories();
	//add a method to save new category details
	String addNewCategory(Category newCategory);
}
