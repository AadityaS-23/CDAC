package com.blogs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blogs.pojos.Category;
import com.blogs.service.CategoryService;

@RestController // @Controller+@ResponseBody
//singleton n eager spring bean - meant for req handling purpose 
@RequestMapping("/categories")
public class CategoryController {
	//depcy - service i/f
	@Autowired 
	private CategoryService categoryService;
	
	public CategoryController() {
		System.out.println("in ctor " + getClass());
	}
	/*
	 * URL - http://host:port/categories
	 * Method - GET
	 * Payload - None
	 * Resp - @ResponseBody List<Category> --> D.S --> Jackson(HTTP converter) : java->json
	 * serialization | marshalling --> sent to REST client (postman|swagger)
	 * Desc - get all categories
	 */
	@GetMapping
	public List<Category> getCategories() {
		System.out.println("in get all categories");
		return categoryService.getAllCategories();
	}
	/*
	 * URL - http://host:port/categories
	 * Method - POST
	 * Payload - JSON representation of Category
	 * Annotation for de-serialization(un marshalling) -Json -> Java : @RequestBody
	 * Resp - @ResponseBody message
	 * Desc - add new  category
	 */
	@PostMapping
	public String addNewCategory(@RequestBody Category category)
	{
		System.out.println("in add new category "+category);
		return categoryService.addNewCategory(category);
	}
	
	
}
